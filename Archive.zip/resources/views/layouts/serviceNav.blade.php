
          <div class="card  mb-xl-9">
        <div class="card-body pb-0">

            <!--end::Details-->
            <div class="separator"></div>
            <!--begin::Nav wrapper-->
            <div class="d-flex overflow-auto h-55px">
                <!--begin::Nav links-->
                <ul class="nav nav-stretch nav-line-tabs nav-line-tabs-2x border-transparent fs-5 fw-bolder flex-nowrap"
                    style="padding-left:40px">
                    <!--begin::Nav item-->
                    <li class="nav-item">
                        <a class="nav-link text-active-primary me-6" href="{{url('manage-Cabin')}}"  >Manage Cabin Babbage</a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link text-active-primary me-6" href="{{url('manage-Cafe')}}"  >Manage Cafe</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-active-primary me-6" href="{{url('manage-Hotel')}}"   >Manage Hotel</a>
                    </li>

                     <li class="nav-item">
                        <a class="nav-link text-active-primary me-6" href="{{url('manage-CareRent')}}"  >Manage  Car Rent</a>
                    </li>

                      <li class="nav-item">
                        <a class="nav-link text-active-primary me-6" href="{{url('editTraining')}}"  >Manage Training</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-active-primary me-6" href="{{url('manage-Park')}}"  >Manage car park</a>
                    </li>
                    <li class="nav-item">
                          <a href="#" class="nav-link text-active-primary me-6" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">
                         Other Pages
                           </a>
                           <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-bold fs-7 w-125px py-4" data-kt-menu="true">
                              
                               <!--begin::Menu item-->
                                <div class="menu-item px-3">
                                   <a href="{{url('manage-Deal')}}" class="menu-link px-3">
                                   manage Deals
                                    </a>
                                   </div>
                               <!--end::Menu item-->                

                               <!--begin::Menu item-->
                                <div class="menu-item px-3">
                                   <a href="{{url('manage-Tourist')}}" class="menu-link px-3">
                                   manage Tourist
                                    </a>
                                   </div>
                               <!--end::Menu item-->       

                                  <!--begin::Menu item-->
                                <div class="menu-item px-3">
                                   <a href="{{url('manage-TravelExtra')}}" class="menu-link px-3">
                                   TravelExtra
                                    </a>
                                   </div>
                               <!--end::Menu item-->     
                                  <!--begin::Menu item-->
                                <div class="menu-item px-3">
                                   <a href="{{url('manage-Special')}}" class="menu-link px-3">
                                   Specail Assist
                                    </a>
                                   </div>
                               <!--end::Menu item-->      

                                 <!--begin::Menu item-->
                                <div class="menu-item px-3">
                                   <a href="{{url('manage-Seat')}}" class="menu-link px-3">
                                   Seat 
                                    </a>
                                   </div>
                               <!--end::Menu item-->                
                              </div>
                            </li>
                             <li class="nav-item">
                        <a class="nav-link text-active-primary me-6" href="{{url('manage-WebBonus')}}"  >Manage WebBonus</a>
                    </li>

                               
            </ul>

            </div>
            <!--end::Nav wrapper-->
        </div>
    </div>