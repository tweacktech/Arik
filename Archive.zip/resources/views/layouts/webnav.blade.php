
          <div class="card  mb-xl-9">
        <div class="card-body pb-0">

            <!--end::Details-->
            <div class="separator"></div>
            <!--begin::Nav wrapper-->
            <div class="d-flex overflow-auto h-55px">
                <!--begin::Nav links-->
                <ul class="nav nav-stretch nav-line-tabs nav-line-tabs-2x border-transparent fs-5 fw-bolder flex-nowrap"
                    style="padding-left:40px">
                    <!--begin::Nav item-->
                    <li class="nav-item">
                        <a class="nav-link text-active-primary me-6" href="{{route('web_content')}}">Web Content</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link text-active-primary me-6" href="{{ route('MissionVission') }}">Mission and Vission</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-active-primary me-6" href="{{ route('CompanyHistory') }}">Company History</a>
                    </li> 
                    
                    
                    <li class="nav-item">
                        <a class="nav-link text-active-primary me-6" href="{{ route('Routing') }} ">Routings</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-active-primary me-6" href="{{ route('Policy') }} ">Policy</a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link text-active-primary me-6" href="{{url('manage-Contact')}}" >Contact Us</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link text-active-primary me-6" href="{{ route('About') }} ">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-active-primary me-6" href="{{ route('Faq') }} ">FAQ</a>
                    </li>
                    

            </ul>

            </div>
            <!--end::Nav wrapper-->
        </div>
    </div>